/* ── landing/landing-copy.ts ──
   Every string on marketing landing page 1, in the app's three languages.

   Deliberately NOT imported from i18n.ts. That file is 227 kB covering every
   screen in the product, and this page's whole reason for existing is that an
   ad click downloads almost nothing. These are the ~50 strings this page
   actually paints, and the three flags, which is all it needs. ── */

export const LANGS = ["th", "en", "zh"];
export const FLAGS = { th: "🇹🇭", en: "🇬🇧", zh: "🇨🇳" };   // same three as the app's settings panel
export const FLAG_NAMES = { th: "ไทย", en: "English", zh: "中文" };

/* ── which language the page opens in ──
   The URL. Nothing else. /landing/ is Thai, /landing-en/ is English,
   /landing-zh/ is Chinese, every time, for everyone.

   Two things it deliberately does NOT consult:

   navigator.language — a large share of phones in Thailand are set to
   English, so Thai visitors arriving from a Thai-language ad were greeted in
   English, which is a worse first impression than no detection at all.

   A previously stored choice — this one was a real bug, not a theory. Tapping
   a flag once saved that language, and from then on it overrode the URL: the
   English and Chinese links both opened in Thai for anyone who had ever used
   the site. Three separate links exist precisely so each campaign lands in
   its own language, and a preference set on a different page is no reason to
   break that.

   The flags still switch the language right now, and that choice is still
   written to the guest profile so the APP opens in it after sign-up — it just
   no longer decides what THIS page opens in. */
export function pickLang(preset) {
  if (LANGS.includes(preset)) return preset;
  return "th";
}

export const C = {
  th: {
    htmlTitle: "ลองเรียนเปียโนกับครู AI — TIGA ALPHA",
    kicker: "ครูเปียโน AI",
    welcomeBack: "ยินดีที่ได้เจออีกครั้ง — บัญชีของคุณพร้อมใช้",
    welcomeGo: "เข้าไปเล่นต่อ →",
    h1a: "ถามครูเปียโน AI แล้ว",
    h1b: "เล่นให้ดูบนคีย์จริง",
    sub: "กดคีย์ได้เลย — ไม่ต้องสมัคร ไม่ต้องโหลดอะไรทั้งนั้น เลือกคำถามสักข้อ แล้ว TIGA จะอธิบายพร้อมเล่นให้ดูทีละนิ้ว",
    tapHint: "👆 ลองกดดูสิ",
    /* Variant B (?v=b — the first-five-seconds test, see LandingPage1): an
       outcome headline instead of a feature headline, the keys light up by
       themselves until the first touch, and one button that goes straight
       into a real song with no account. The control copy above is untouched. */
    vb: {
      h1a: "เล่นเปียโนได้ตั้งแต่วินาทีนี้ ",
      h1b: "ครู AI สอนทีละนิ้ว",
      sub: "แตะคีย์ได้เลย ไม่ต้องสมัคร ไม่ต้องโหลดอะไร แล้วให้ครู AI เล่นให้ดูทีละนิ้ว",
    },
    firstSong: "▶ เล่นเพลงแรกเลย (ไม่ต้องสมัคร)",
    greet: "สวัสดีครับ ผมคือ TIGA ครูเปียโน AI 🎹\nอยากให้สอนเรื่องไหนก่อนดีครับ? เลือกได้เลย — ตอบทันที ไม่ต้องสมัครสมาชิก",
    chipHint: "แตะสักข้อ แล้วดูคีย์บอร์ดข้างบน",
    askPh: "ถาม TIGA AI เรื่องเรียนเปียโน",
    askBtn: "ถาม",
    askFree: "ถามฟรีได้อีก {n} คำถาม — ตอบโดย AI จริง ไม่ต้องสมัคร",
    askThinking: "TIGA กำลังคิด…",
    askFailed: "ขอโทษครับ ตอนนี้ตอบไม่ได้ ลองถามอีกครั้งได้ไหมครับ",
    askQuotaTitle: "ถามต่อได้ไม่จำกัด 🎹",
    askTimeTitle: "หมดเวลาทดลองแล้ว 🎹",
    askTimeBody: "คุณลองมา 3 นาทีแล้ว — สมัครฟรีเพื่อเล่นและถามต่อได้ไม่จำกัด ไม่ต้องใช้บัตร",
    sticky: "สมัครวันนี้ — ทดลองฟรี 7 วัน แล้วต่อเดือนละ 799 บาท ไม่ต้องใช้บัตร",
    nudgeLine: "ถูกใจคำตอบนี้ไหม? สมัครฟรีแล้วถามได้ไม่จำกัด พร้อมเซฟความคืบหน้าของคุณ",
    nudgeBtn: "สมัครฟรี 5 วินาที",
    nudgeDismiss: "ไว้ก่อนนะ",
    proof1: "เพลงที่เราแต่งเอง เล่นตามได้ทุกเพลง", proof2: "ถามได้ทุกเรื่อง", proof3: "ทดลองฟรี ไม่ต้องใช้บัตร",
    /* 100,000 is the size of the original shelf, counted from
       public/originals/index.json — see scripts/smoke-landing-three-langs.mjs,
       which fails if the headline outruns the data. */
    proofSongs: "100,000+",
    /* The 7-day promise belongs where it is always on screen. The sticky bar
       only fades in after 15s and the trial line only exists inside the
       signup card, so a visitor who reads the page top to bottom and leaves
       never saw "7 วัน" at all. No tier is named: the checkout is what
       decides a tier, and the cap is an internal promotion detail. */
    proofDays: "7 วัน",
    signupTitleQ: "คำถามของคุณพร้อมแล้ว 🎹",
    signupTitle: "เปิดห้องเรียนของคุณเอง 🎹",
    signupBody: "สี่คำตอบเมื่อกี้เป็นบทเรียนสำเร็จรูป — ของจริงคือ TIGA ตอบคำถามของคุณเองได้ไม่จำกัด จำได้ว่าคุณติดตรงไหน และเลือกแบบฝึกให้ตรงจุดอ่อน สมัครฟรี ไม่ต้องใช้บัตร",
    qLabel: "คำถามที่คุณถาม",
    google: "สมัคร / เข้าสู่ระบบด้วย Google",
    googleInApp: "สมัครด้วย Google (ต้องเปิดในเบราว์เซอร์จริง)",
    lineBtn: "สมัคร / เข้าสู่ระบบด้วย LINE",
    trialLine: "🎁 สมัครฟรี ทดลองเล่นได้ครบทุกฟีเจอร์ 7 วัน แล้วต่อเดือนละ 799 บาท — ไม่ต้องใช้บัตร",
    or: "หรือ",
    emailBtn: "สมัครด้วยอีเมล",
    emailFullBtn: "สมัครด้วยรหัสผ่านแทน",
    otpBtn: "ส่งลิงก์เข้าสู่ระบบฟรี",
    otpDone: "ส่งลิงก์แล้ว! เปิดอีเมลแล้วกดลิงก์เพื่อเข้าเรียนทันที — ไม่ต้องมีรหัสผ่าน · Magic link sent — open your email and tap it to start.",
    inApp: "คุณกำลังเปิดจากในแอปอื่น (Facebook / LINE / IG) ซึ่งปุ่ม Google มักใช้ไม่ได้ — สมัครด้วยอีเมลข้างล่างได้เลย หรือกดเปิดในเบราว์เซอร์จริงก่อน",
    namePh: "ชื่อที่อยากให้ครูเรียก",
    emailPh: "อีเมล",
    passPh: "รหัสผ่าน (อย่างน้อย 6 ตัว)",
    agree: "ฉันยอมรับ", agreeLink: "นโยบายความเป็นส่วนตัว",
    agreeTail: " และยินยอมให้เก็บข้อมูลเพื่อให้บริการเรียนเปียโน",
    marketing: "ยินดีรับข่าวสารและโปรโมชัน (ไม่บังคับ)",
    submit: "สมัครฟรี", submitBusy: "กำลังสมัคร…",
    useGoogle: "ใช้ Google แทน",
    openReal: "เปิดในเบราว์เซอร์จริง",
    openTop: "เปิดในเบราว์เซอร์",
    openWhy: "เปิดใน Browser กดปุ่มมุมขวาเพื่อใช้งานเต็มรูปแบบ",
    openCopied: "คัดลอกลิงก์แล้ว — ถ้าไม่เด้งเอง เปิดเบราว์เซอร์แล้ววางได้เลย",
    escTitle: "เปิดใน Chrome เพื่อสมัครด้วย Google",
    escBody: "คุณกำลังเปิดหน้านี้จากในแอปอื่น ซึ่ง Google ไม่อนุญาตให้ล็อกอิน — กดปุ่มข้างล่างเพื่อเปิดในเบราว์เซอร์จริง (ลิงก์ถูกคัดลอกไว้แล้ว) หรือสมัครด้วยอีเมลต่อได้เลย",
    escStay: "สมัครด้วยอีเมลในหน้านี้ต่อ",
    gateTitle: "เล่นได้จริงใช่ไหมล่ะ 🎹",
    gateSub: "นั่นคือสิ่งที่ TIGA ทำได้ทุกวันกับคุณ — เปิดบัญชีฟรี ใส่แค่อีเมล แล้วเริ่มเรียนกับครู AI ได้เลย ไม่ต้องใช้บัตร",
    gateBtn: "เริ่มเรียนฟรี — ใส่แค่อีเมล",
    gateGoogle: "ล็อกอินผ่าน Google",
    heroGoogle: "สมัครเริ่มเรียนฟรีด้วย Google", heroTry: "หรือลองถามครูก่อน ↓",
    gateSkip: "ดูต่อโดยไม่สมัครก่อน",
    have: "มีบัญชีอยู่แล้ว?", haveLink: "เข้าสู่ระบบในแอป",
    footTag: "TIGA AI · เรียนเปียโนกับครู AI",
    enterApp: "เข้าแอปเลย", privacy: "นโยบายความเป็นส่วนตัว", allSongs: "เพลงทั้งหมด",
    errName: "กรุณากรอกชื่อที่อยากให้ครูเรียก · Please enter a name",
    errFields: "กรุณากรอกอีเมลและรหัสผ่าน · Please enter your email and password",
    errShort: "รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร · Password must be at least 6 characters",
    errAgree: "กรุณายอมรับนโยบายความเป็นส่วนตัวก่อนสมัคร · Please accept the privacy notice to continue",
    done: "สมัครสำเร็จ! ตรวจสอบอีเมลเพื่อยืนยันบัญชี แล้วกลับมาเข้าสู่ระบบ · Account created — check your email to confirm it, then log in.",
  },

  en: {
    htmlTitle: "Try a piano lesson with an AI teacher — TIGA ALPHA",
    kicker: "AI PIANO TEACHER",
    welcomeBack: "Welcome back — your account is ready",
    welcomeGo: "Continue to the app →",
    h1a: "An AI piano teacher that ",
    h1b: "plays the answer",
    sub: "Tap the keys now — no sign-up, nothing to install. Ask, and TIGA plays it for you, finger by finger.",
    tapHint: "👆 Tap a key",
    vb: {
      h1a: "Play the piano ",
      h1b: "from this very second",
      sub: "Tap the keys now: no sign-up, nothing to install. Then let the AI teacher show you, finger by finger.",
    },
    firstSong: "▶ Play your first song (no sign-up)",
    greet: "Hi, I'm TIGA, your AI piano teacher 🎹\nPick a topic — I'll play it for you.",
    chipHint: "Tap one, then watch the keyboard above",
    askPh: "Ask TIGA AI about piano",
    askBtn: "Ask",
    askFree: "{n} free questions left — answered by the real AI, no account",
    askThinking: "TIGA is thinking…",
    askFailed: "Sorry — I couldn't answer just then. Try asking again?",
    askQuotaTitle: "Keep asking, without limit 🎹",
    askTimeTitle: "That's the free trial 🎹",
    askTimeBody: "You've had three minutes — sign up free to keep playing and keep asking, without limit. No card needed.",
    sticky: "Sign up today — 7 days free to try, then 799 THB/month, no card",
    nudgeLine: "Like that answer? Sign up free to ask without limit — and keep your progress.",
    nudgeBtn: "Sign up in 5 seconds",
    nudgeDismiss: "Maybe later",
    proof1: "songs we wrote ourselves, every one playable", proof2: "ask it anything", proof3: "free to try, no card needed",
    proofSongs: "100,000+",
    proofDays: "7 days",
    signupTitleQ: "Your question is ready 🎹",
    signupTitle: "Open your own classroom 🎹",
    signupBody: "Those four answers are ready-made lessons. The real thing is TIGA answering your own questions, with no limit — remembering where you got stuck and picking exercises for exactly that. Free, no card needed.",
    qLabel: "The question you asked",
    google: "Sign up / log in with Google",
    googleInApp: "Sign up with Google (needs your real browser)",
    lineBtn: "Sign up / log in with LINE",
    trialLine: "🎁 Sign up free — 7 days to try everything, then 799 THB/month, no card",
    or: "or",
    emailBtn: "Sign up with email",
    emailFullBtn: "Sign up with a password instead",
    otpBtn: "Email me a free sign-in link",
    otpDone: "Link sent! Open your email and tap it to start learning — no password needed.",
    inApp: "You've opened this inside another app (Facebook / LINE / IG), where the Google button usually can't work — sign up with email below, or open this in your real browser first.",
    namePh: "What should your teacher call you?",
    emailPh: "Email",
    passPh: "Password (at least 6 characters)",
    agree: "I accept the ", agreeLink: "privacy notice",
    agreeTail: " and consent to my data being used to provide piano lessons",
    marketing: "Send me news and offers (optional)",
    submit: "Sign up free", submitBusy: "Signing you up…",
    useGoogle: "Use Google instead",
    openReal: "Open in a real browser",
    openTop: "Open in browser",
    openWhy: "Open in Browser — top-right button, for full access",
    openCopied: "Link copied — if nothing opened, paste it into your browser",
    escTitle: "Open in Chrome to sign up with Google",
    escBody: "This page opened inside another app, and Google blocks sign-ins there — tap below to open your real browser (the link is already copied), or keep going with email instead.",
    escStay: "Continue with email here",
    gateTitle: "It really plays, right? 🎹",
    gateSub: "That is what TIGA does all day, every day, with you — a free account, one email, and you're learning with your AI teacher. No card needed.",
    gateBtn: "Start free — just an email",
    gateGoogle: "Sign in with Google",
    heroGoogle: "Sign up free with Google", heroTry: "or try asking the teacher first ↓",
    gateSkip: "Keep looking without an account",
    have: "Already have an account?", haveLink: "Log in inside the app",
    footTag: "TIGA AI · learn piano with an AI teacher",
    enterApp: "Go to the app", privacy: "Privacy notice", allSongs: "All songs",
    errName: "Please enter a name",
    errFields: "Please enter your email and password",
    errShort: "Password must be at least 6 characters",
    errAgree: "Please accept the privacy notice to continue",
    done: "Account created — check your email to confirm it, then log in.",
  },

  zh: {
    htmlTitle: "和 AI 钢琴老师试上一课 — TIGA ALPHA",
    kicker: "AI 钢琴老师",
    welcomeBack: "欢迎回来 — 你的账号已就绪",
    welcomeGo: "进入应用 →",
    h1a: "问 AI 钢琴老师，看它",
    h1b: "在真实琴键上弹给你看",
    sub: "下面的琴键现在就能弹——不用注册，不用下载。挑一个问题，TIGA 会一边讲解一边一个音一个音弹给你看。",
    tapHint: "👆 点一下试试",
    vb: {
      h1a: "现在就能弹钢琴，",
      h1b: "AI 老师一指一指教你",
      sub: "点琴键就行：无需注册，无需下载。再让 AI 老师一个手指一个手指弹给你看。",
    },
    firstSong: "▶ 弹第一首歌（无需注册）",
    greet: "你好，我是 TIGA，你的 AI 钢琴老师 🎹\n想先学哪一个？随便挑——马上回答，不用注册。",
    chipHint: "点一个，然后看上面的键盘",
    askPh: "问 TIGA AI 任何钢琴问题",
    askBtn: "问",
    askFree: "还能免费问 {n} 个问题 —— 由真正的 AI 回答，无需注册",
    askThinking: "TIGA 正在思考…",
    askFailed: "抱歉，刚才没能回答。再问一次好吗？",
    askQuotaTitle: "无限次提问 🎹",
    askTimeTitle: "免费试用结束 🎹",
    askTimeBody: "你已经体验了三分钟——免费注册即可无限继续弹奏和提问，无需银行卡。",
    sticky: "今天就注册 — 免费试用 7 天，之后每月 799 泰铢，无需银行卡",
    nudgeLine: "喜欢这个回答？免费注册即可无限提问，并保存你的学习进度。",
    nudgeBtn: "5 秒完成注册",
    nudgeDismiss: "以后再说",
    proof1: "我们的原创曲目，全部可跟弹", proof2: "什么都能问", proof3: "免费试用，无需银行卡",
    proofSongs: "100,000+",
    proofDays: "7 天",
    signupTitleQ: "你的问题准备好了 🎹",
    signupTitle: "开一间属于你的教室 🎹",
    signupBody: "刚才那四个回答是现成的课程。真正厉害的是 TIGA 能无限回答你自己的问题，记住你卡在哪里，并针对你的弱项挑练习。免费注册，无需银行卡。",
    qLabel: "你问的问题",
    google: "用 Google 注册 / 登录",
    googleInApp: "用 Google 注册（需在真实浏览器中打开）",
    lineBtn: "用 LINE 注册 / 登录",
    trialLine: "🎁 免费注册即享 7 天完整试用，之后每月 799 泰铢——无需银行卡",
    or: "或",
    emailBtn: "用邮箱注册",
    emailFullBtn: "改用密码注册",
    otpBtn: "发送免费登录链接到邮箱",
    otpDone: "链接已发送！打开邮箱点击链接即可开始学习——无需密码。",
    inApp: "你是从别的 App（Facebook / LINE / IG）里打开的，Google 按钮在这里通常无法使用——请用下面的邮箱注册，或先在真正的浏览器中打开。",
    namePh: "希望老师怎么称呼你？",
    emailPh: "邮箱",
    passPh: "密码（至少 6 位）",
    agree: "我接受", agreeLink: "隐私政策",
    agreeTail: "，并同意为提供钢琴教学而使用我的数据",
    marketing: "接收消息与优惠（选填）",
    submit: "免费注册", submitBusy: "注册中…",
    useGoogle: "改用 Google",
    openReal: "在真正的浏览器中打开",
    openTop: "用浏览器打开",
    openWhy: "请用浏览器打开 — 点击右上角按钮体验完整功能",
    openCopied: "链接已复制 — 如果没有自动打开，请在浏览器中粘贴",
    escTitle: "在 Chrome 中打开，用 Google 注册",
    escBody: "此页面在其他 App 内打开，Google 不允许在这里登录——点击下方按钮在真正的浏览器中打开（链接已复制），也可以继续用邮箱注册。",
    escStay: "继续用邮箱注册",
    gateTitle: "真的会弹吧？🎹",
    gateSub: "TIGA 每天都能为你做到——免费注册，只需一个邮箱，就能开始跟 AI 老师学习。无需银行卡。",
    gateBtn: "免费开始——只需邮箱",
    gateGoogle: "用 Google 登录",
    heroGoogle: "用 Google 免费注册开始学习", heroTry: "或者先问问老师 ↓",
    gateSkip: "先不注册，继续看看",
    have: "已经有账号？", haveLink: "在 App 中登录",
    footTag: "TIGA AI · 跟 AI 老师学钢琴",
    enterApp: "进入 App", privacy: "隐私政策", allSongs: "全部曲目",
    errName: "请输入一个名字",
    errFields: "请输入邮箱和密码",
    errShort: "密码至少需要 6 个字符",
    errAgree: "请先接受隐私政策才能注册",
    done: "注册成功！请查收邮件确认账号，然后回来登录。",
  },
};
